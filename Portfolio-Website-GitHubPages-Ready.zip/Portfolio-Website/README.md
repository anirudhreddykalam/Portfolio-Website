
# Portfolio-Website (GitHub Pages ready)

This repo contains a static portfolio site optimized for **project sites** on GitHub Pages (served at `https://<username>.github.io/Portfolio-Website/`).

## Deploy
1. Create a GitHub repo named `Portfolio-Website`.
2. Upload everything in this folder:
   - `index.html`
   - `.nojekyll`
   - `assets/` (put your resume as `Anirudh_Reddy_Resume.pdf`)
3. Settings → Pages → Source: **Deploy from a branch**, Branch: **main**, Folder: **/(root)**.
4. Open `https://<username>.github.io/Portfolio-Website/`.

## Notes
- All paths are **relative** (e.g. `./assets/...`) so they work from a sub-path.
- Keep the filename `index.html` in lowercase.
